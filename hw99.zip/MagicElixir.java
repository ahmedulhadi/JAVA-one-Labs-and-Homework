class MagicElixir extends Potion {

    MagicElixir() {
        super();
    }

}