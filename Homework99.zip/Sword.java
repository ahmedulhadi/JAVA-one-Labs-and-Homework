class Sword extends Weapon {
    Sword() {

        super();
    }
}