class Blaster extends Weapon {
    Blaster() {
        super(10);
    }

}