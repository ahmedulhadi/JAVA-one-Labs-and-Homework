public class Player {
    String name;
    int health;

    Player(String name) {
        this.name = name;
        this.health = 100;
    }

    String getName() {
        return name;
    }

    int getHealth() {
        return health;
    }

    public void sufferDamage(int damage) {

        this.health = this.health - damage;
    }

    public void attack(Player opponent, Weapon weapon) {

        opponent.sufferDamage(weapon.getDamage());

    }

    public void drink(Potion potion) {

        if (this.health + potion.getBenefit() >= 100) {

            this.health = 100;
            potion.drink();
        } else {
            this.health = this.health + potion.getBenefit();
            potion.drink();
        }
    }

}

class Potion {
    String name;
    int benefit;

    Potion(String name) {
        this.name = name;
        this.benefit = 10;
    }

    Potion() {
        this.name = "MagicalElixir";
        this.benefit = 20;
    }

    int getBenefit() {
        return benefit;
    }

    String getName() {
        return name;
    }

    int drink() {
        this.benefit = 0;
        return benefit;

    }
}

class Weapon {
    String name;
    int damage;

    Weapon(String name) {
        this.name = name;
        this.damage = 0;
    }

    Weapon() {
        this.name = "Sword";
        this.damage = 5;
    }

    Weapon(int damage) {
        this.name = "Blaster";
        this.damage = 15;
    }

    int getDamage() {
        return damage;
    }

    String getName() {
        return name;
    }

}

class MagicalElixir extends Potion {

    MagicalElixir() {
        super();
    }

}

class Sword extends Weapon {
    Sword() {

        super();
    }
}

class Blaster extends Weapon {
    Blaster() {
        super(10);
    }

}