public class Potion {
    String name;
    int benefit;

    Potion(String name) {
        this.name = name;
        this.benefit = 10;
    }

    int getBenefit() {
        return benefit;
    }

    int drink() {
        this.benefit = 0;
        return benefit;

    }
}